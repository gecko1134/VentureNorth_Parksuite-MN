import streamlit as st
def run():
    st.title("Weekly Report Generator")
    st.write("Generates summary reports and emails to board.")